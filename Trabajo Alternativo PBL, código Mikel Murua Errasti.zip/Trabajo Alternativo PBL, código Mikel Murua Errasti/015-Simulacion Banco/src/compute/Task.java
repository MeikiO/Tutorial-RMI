package compute;

public interface Task<T> {
    T recibirOrden();
}
