package common;

public interface Tareas {
	String saludar(String nombre);
}
