package common;

public interface Calculadora { //TODO
	//TODO
}
