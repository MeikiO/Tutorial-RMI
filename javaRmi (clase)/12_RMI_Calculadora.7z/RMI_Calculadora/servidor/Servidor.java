package servidor;

import common.Calculadora;

public class Servidor{

	public static void main(String[] args) {
		//TODO

	}
}